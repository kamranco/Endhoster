const modal = document.getElementById('authModal');
const authForm = document.getElementById('authForm');
const authTitle = document.getElementById('authTitle');
const usernameWrap = document.getElementById('usernameWrap');
const usernameInput = document.getElementById('authUsername');
const emailInput = document.getElementById('authEmail');
const passwordInput = document.getElementById('authPassword');
const authSubmit = document.getElementById('authSubmit');
const authMessage = document.getElementById('authMessage');
let mode = 'register';

function openModal(nextMode = 'register') { modal.hidden = false; setMode(nextMode); }
function closeModal() { modal.hidden = true; }
function setMode(nextMode) {
  mode = nextMode;
  document.querySelectorAll('.auth-tab').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  authTitle.textContent = mode === 'register' ? 'Konto erstellen' : 'Willkommen zurück';
  authSubmit.textContent = mode === 'register' ? 'Konto erstellen' : 'Anmelden';
  usernameWrap.hidden = mode === 'login';
  usernameInput.required = mode === 'register';
  passwordInput.autocomplete = mode === 'register' ? 'new-password' : 'current-password';
  passwordInput.minLength = mode === 'register' ? 10 : 1;
  authMessage.textContent = '';
}
document.getElementById('navAuth').addEventListener('click', () => openModal('login'));
document.getElementById('heroAuth').addEventListener('click', () => openModal('register'));
document.getElementById('closeAuth').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
document.querySelectorAll('.auth-tab').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));

async function api(path, body) {
  const response = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Etwas ist schiefgelaufen.');
  return data;
}
authForm.addEventListener('submit', async e => {
  e.preventDefault();
  authSubmit.disabled = true;
  authMessage.textContent = 'Bitte warten …';
  try {
    const payload = { email: emailInput.value.trim(), password: passwordInput.value };
    if (mode === 'register') payload.username = usernameInput.value.trim();
    const data = await api(mode === 'register' ? '/api/auth/register' : '/api/auth/login', payload);
    authMessage.textContent = data.message || 'Erfolgreich.';
    await loadMe();
    setTimeout(closeModal, 700);
  } catch (err) {
    authMessage.textContent = err.message;
  } finally {
    authSubmit.disabled = false;
  }
});

async function loadMe() {
  const response = await fetch('/api/auth/me', { credentials: 'same-origin' });
  const data = await response.json();
  const user = data.user;
  const navAuth = document.getElementById('navAuth');
  const logoutBtn = document.getElementById('logoutBtn');
  if (!user) {
    document.getElementById('navUser').textContent = '';
    navAuth.hidden = false;
    logoutBtn.hidden = true;
    document.getElementById('welcomeTitle').textContent = 'Willkommen bei Minehoster';
    document.getElementById('welcomeText').textContent = 'Melde dich an, um deinen Account-Bereich zu öffnen.';
    document.getElementById('avatar').textContent = '?';
    document.getElementById('accountName').textContent = 'Noch nicht angemeldet';
    document.getElementById('accountEmail').textContent = 'Melde dich an oder erstelle ein Konto.';
    document.getElementById('accountStatus').textContent = 'Gastmodus';
    return;
  }
  document.getElementById('navUser').textContent = `Hi, ${user.username}`;
  navAuth.hidden = true;
  logoutBtn.hidden = false;
  document.getElementById('welcomeTitle').textContent = `Hallo, ${user.username}!`;
  document.getElementById('welcomeText').textContent = 'Du bist angemeldet. Dein Serverbereich ist bereit für den nächsten Entwicklungsschritt.';
  document.getElementById('avatar').textContent = user.username.slice(0, 1).toUpperCase();
  document.getElementById('accountName').textContent = user.username;
  document.getElementById('accountEmail').textContent = user.email;
  document.getElementById('accountStatus').textContent = 'Angemeldet';
}
document.getElementById('logoutBtn').addEventListener('click', async () => {
  try {
    const r = await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    if (!r.ok) throw new Error('Abmeldung fehlgeschlagen.');
    await loadMe();
  } catch (e) { alert(e.message); }
});
loadMe().catch(() => {});
