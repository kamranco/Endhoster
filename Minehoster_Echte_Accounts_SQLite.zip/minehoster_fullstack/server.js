const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET to a random secret of at least 32 characters before starting.');
  process.exit(1);
}

const db = new Database(process.env.DB_PATH || path.join(__dirname, 'minehoster.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));

const isProduction = process.env.NODE_ENV === 'production';
app.use(session({
  name: 'minehoster.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
  // For production, replace the default MemoryStore with a maintained
  // persistent session store such as a SQLite/Redis-backed store.
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { error: 'Zu viele Versuche. Bitte warte 15 Minuten.' }
});
app.use('/api/auth', authLimiter);
app.use(express.static(path.join(__dirname, 'public')));

const getUserById = db.prepare('SELECT id, username, email, created_at FROM users WHERE id = ?');
const getUserByEmail = db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE');
const getUserByUsername = db.prepare('SELECT id FROM users WHERE username = ? COLLATE NOCASE');
const insertUser = db.prepare('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}
function validUsername(username) {
  return /^[A-Za-z0-9_]{3,24}$/.test(username);
}
function safeUser(user) {
  return { id: user.id, username: user.username, email: user.email, createdAt: user.created_at };
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Bitte melde dich zuerst an.' });
  const user = getUserById.get(req.session.userId);
  if (!user) {
    req.session.destroy(() => {});
    return res.status(401).json({ error: 'Sitzung ungültig. Bitte melde dich erneut an.' });
  }
  req.user = user;
  next();
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'minehoster-auth' }));

app.post('/api/auth/register', async (req, res) => {
  const username = String(req.body.username || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');

  if (!validUsername(username)) {
    return res.status(400).json({ error: 'Der Benutzername muss 3–24 Zeichen lang sein und darf nur Buchstaben, Zahlen und _ enthalten.' });
  }
  if (!validEmail(email)) return res.status(400).json({ error: 'Bitte gib eine gültige E-Mail-Adresse ein.' });
  if (password.length < 10 || password.length > 72) {
    return res.status(400).json({ error: 'Das Passwort muss 10–72 Zeichen lang sein.' });
  }

  if (getUserByUsername.get(username)) return res.status(409).json({ error: 'Dieser Benutzername ist bereits vergeben.' });
  if (getUserByEmail.get(email)) return res.status(409).json({ error: 'Für diese E-Mail gibt es bereits ein Konto.' });

  try {
    const hash = await bcrypt.hash(password, 12);
    const result = insertUser.run(username, email, hash);
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: 'Sitzung konnte nicht erstellt werden.' });
      req.session.userId = Number(result.lastInsertRowid);
      res.status(201).json({ user: { id: Number(result.lastInsertRowid), username, email }, message: 'Konto erstellt.' });
    });
  } catch (err) {
    if (String(err.code || '').startsWith('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'Benutzername oder E-Mail ist bereits vergeben.' });
    console.error(err);
    res.status(500).json({ error: 'Konto konnte nicht erstellt werden.' });
  }
});

app.post('/api/auth/login', (req, res, next) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = getUserByEmail.get(email);
  if (!user) return res.status(401).json({ error: 'E-Mail oder Passwort ist falsch.' });
  bcrypt.compare(password, user.password_hash).then(matches => {
    if (!matches) return res.status(401).json({ error: 'E-Mail oder Passwort ist falsch.' });
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = user.id;
      res.json({ user: safeUser(user), message: 'Angemeldet.' });
    });
  }).catch(next);
});

app.get('/api/auth/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = getUserById.get(req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: safeUser(user) });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Abmeldung fehlgeschlagen.' });
    res.clearCookie('minehoster.sid', { httpOnly: true, sameSite: 'lax', secure: isProduction });
    res.json({ message: 'Abgemeldet.' });
  });
});

app.get('/api/account', requireAuth, (req, res) => {
  res.json({ user: safeUser(req.user), servers: [], note: 'Serververwaltung ist noch nicht angebunden.' });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Interner Serverfehler.' });
});

app.listen(PORT, () => {
  console.log(`Minehoster läuft auf http://localhost:${PORT}`);
  console.log('Demo-Website und echte lokale Account-Datenbank gestartet.');
});
