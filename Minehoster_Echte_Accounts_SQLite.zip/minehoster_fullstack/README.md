# Minehoster – echte lokale Benutzerkonten

Diese Version erweitert die Website um ein serverseitiges Konto-System mit SQLite.
Passwörter werden mit bcrypt gehasht und nicht im Browser gespeichert.

## Voraussetzungen
- Node.js 20 oder neuer
- npm

## Starten
1. ZIP entpacken.
2. Im Ordner `minehoster-fullstack` ein Terminal öffnen.
3. Abhängigkeiten installieren:

   ```bash
   npm install
   ```

4. Einen zufälligen geheimen Sitzungsschlüssel setzen.

   macOS/Linux:
   ```bash
   export SESSION_SECRET="$(node -e \"console.log(require('crypto').randomBytes(48).toString('hex'))\")"
   npm start
   ```

   Windows PowerShell:
   ```powershell
   $env:SESSION_SECRET = node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
   npm start
   ```

5. `http://localhost:3000` im Browser öffnen.

Die Datei `minehoster.sqlite` wird beim ersten Start automatisch angelegt.

## Funktionen
- Registrierung mit Benutzername, E-Mail und Passwort
- Anmeldung und Abmeldung
- Serverseitige Passwort-Hashes mit bcrypt
- SQLite-Datenbank für Konten
- Sitzungscookie mit HttpOnly und SameSite
- Rate-Limit für Authentifizierungs-Endpunkte
- Helmet-Sicherheitsheader

## Wichtige Grenzen
- Das ist ein Starterprojekt, kein fertiger öffentlicher Hosting-Dienst.
- Vor Veröffentlichung: HTTPS aktivieren, einen persistenten Session-Store konfigurieren, E-Mail-Verifizierung und Passwort-Zurücksetzen ergänzen, Backups und Datenschutz-/Impressumsseiten einrichten sowie Abhängigkeiten aktuell halten.
- Registrierte Konten werden auf diesem Server gespeichert. Die Datenbank ist lokal, solange du keinen Server/Hosting-Dienst dafür bereitstellst.
- Es werden noch keine Minecraft-Server automatisch erzeugt oder gestartet.
- Die Serververwaltung muss später mit einem isolierten Worker/Container-System verbunden werden. Starte niemals beliebige hochgeladene JAR-Dateien direkt im Webprozess.
